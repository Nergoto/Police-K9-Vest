Credits: Hankos Vest, Nergoto

For any help: https://discord.gg/se2fYjFsmD